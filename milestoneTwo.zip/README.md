# sharegroup-fork
Group members:
  Joshua Wilding
  Terik Brunson
  Matthew Morris
  Chris Tibbetts

This is a fork of the original repository for CS 2610
For this reason, the commit messages for this project are spread across three different GitHub repositories.
The GitHub repositories are:
  https://github.com/joshwilding4444/sharegroup
  https://github.com/tibbittschris/mainproject
  https://github.com/joshwilding4444/sharegroup-fork

The latest fork, with the most current data, is https://github.com/joshwilding4444/sharegroup-fork.
