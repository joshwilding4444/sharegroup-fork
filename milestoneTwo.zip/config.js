var config = {}

config.access_token = ''
config.client_id = 'afdc0b4978f149cab3801f5501116ebd'
config.client_secret = '341145521ab545beb9ac1eef625cbd7c'
config.redirect_uri = 'http://127.0.0.1:3000/auth/finalize'

module.exports = config
